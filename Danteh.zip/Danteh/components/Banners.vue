<template>
  <div class="container-fluid">
    <div class="row">
      <div class="col">
        <img class="shadow-sm banner" src="@/assets/xiaomi.webp" alt="ads"/>
      </div>
    </div>
    <div class="row">
      <div class="col text-center">
        <img class="shadow-sm banner" src="@/assets/snowa-ad.gif" alt="ads"/>
        <img class="shadow-sm banner" src="@/assets/meghdad.gif" alt="ads"/>
      </div>

    </div>
  </div>

</template>

<style scoped>
.banner{
    max-width: 100%;
    border-radius: 8px;
    margin-bottom: 16px;
}

</style>
