<template>
    <div class="main"></div>
</template>
<script>
import header from '@/layouts/header'
export default {
    layout: "header"
}
</script>