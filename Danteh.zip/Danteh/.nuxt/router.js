import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _d111d1d4 = () => interopDefault(import('..\\pages\\getProducts.vue' /* webpackChunkName: "pages/getProducts" */))
const _c257c4fe = () => interopDefault(import('..\\pages\\header.vue' /* webpackChunkName: "pages/header" */))
const _3ddd8faa = () => interopDefault(import('..\\pages\\products\\index.vue' /* webpackChunkName: "pages/products/index" */))
const _17cafc06 = () => interopDefault(import('..\\pages\\test.vue' /* webpackChunkName: "pages/test" */))
const _0b56d3e0 = () => interopDefault(import('..\\pages\\products\\_slug\\index.vue' /* webpackChunkName: "pages/products/_slug/index" */))
const _0b2b7fe4 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/awk/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/getProducts",
    component: _d111d1d4,
    name: "getProducts"
  }, {
    path: "/header",
    component: _c257c4fe,
    name: "header"
  }, {
    path: "/products",
    component: _3ddd8faa,
    name: "products"
  }, {
    path: "/test",
    component: _17cafc06,
    name: "test"
  }, {
    path: "/products/:slug",
    component: _0b56d3e0,
    name: "products-slug"
  }, {
    path: "/",
    component: _0b2b7fe4,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
