export { default as Alert } from '../..\\components\\alert.vue'
export { default as Banners } from '../..\\components\\Banners.vue'
export { default as Footer } from '../..\\components\\Footer.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as NavTable } from '../..\\components\\NavTable.vue'
export { default as ProductCarCopy } from '../..\\components\\ProductCar copy.vue'
export { default as ProductCar } from '../..\\components\\ProductCar.vue'
export { default as ProductCard } from '../..\\components\\ProductCard.vue'
export { default as ProductSection } from '../..\\components\\ProductSection.vue'
export { default as TextInput } from '../..\\components\\text-input.vue'

export const LazyAlert = import('../..\\components\\alert.vue' /* webpackChunkName: "components_alert" */).then(c => c.default || c)
export const LazyBanners = import('../..\\components\\Banners.vue' /* webpackChunkName: "components_Banners" */).then(c => c.default || c)
export const LazyFooter = import('../..\\components\\Footer.vue' /* webpackChunkName: "components_Footer" */).then(c => c.default || c)
export const LazyHeader = import('../..\\components\\Header.vue' /* webpackChunkName: "components_Header" */).then(c => c.default || c)
export const LazyNavTable = import('../..\\components\\NavTable.vue' /* webpackChunkName: "components_NavTable" */).then(c => c.default || c)
export const LazyProductCarCopy = import('../..\\components\\ProductCar copy.vue' /* webpackChunkName: "components_ProductCar copy" */).then(c => c.default || c)
export const LazyProductCar = import('../..\\components\\ProductCar.vue' /* webpackChunkName: "components_ProductCar" */).then(c => c.default || c)
export const LazyProductCard = import('../..\\components\\ProductCard.vue' /* webpackChunkName: "components_ProductCard" */).then(c => c.default || c)
export const LazyProductSection = import('../..\\components\\ProductSection.vue' /* webpackChunkName: "components_ProductSection" */).then(c => c.default || c)
export const LazyTextInput = import('../..\\components\\text-input.vue' /* webpackChunkName: "components_text-input" */).then(c => c.default || c)
