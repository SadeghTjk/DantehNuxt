<template>
    <div class="single">
        SINGLE
    </div>
</template>