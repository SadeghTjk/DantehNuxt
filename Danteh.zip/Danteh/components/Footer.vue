<template>
<div class="container-fluid shadow-sm">
    <div class="row">
        <div class="col bg-dark footer-above">
            <input class="bg-light newssub" type="text" id="newsletter" placeholder="عضویت در خبرنامه" />
        </div>
    </div>
    <div class="row">
        <div class="col-2 bg-danger">
                s
        </div>
        <div class="col-2 bg-dark">

        </div>
        <div class="col-2 bg-info">
                
        </div>
        <div class="col-2 bg-primary">
                
        </div>
        <div class="col-4 bg-warning">
                
        </div>
    </div>
</div>
    
</template>

<script>
export default {
    
}
</script>

<style scoped>
.footer-above{
    border-radius: 56px;
    text-align: center;
    height: 56px;
}
input#newsletter {
    height: 50px;
    margin-top: 3px;
    border-radius: 50px;
    width: 50%;
    direction: rtl;
    padding: 20px;
    border: 0;
}
</style>